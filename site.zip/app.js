import { initializeApp } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js";
import { getAuth, signInAnonymously } from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";
import {
  getFirestore, collection, doc, getDocs, query, orderBy, limit,
  onSnapshot, writeBatch, runTransaction, serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const money = new Intl.NumberFormat("en-MY", { style: "currency", currency: "MYR" });
const todayKey = () => new Date().toISOString().slice(0, 10);

const translations = {
  en: {
    brandSubtitle: "Sales and Inventory", navOverview: "Overview", navSale: "New Invoice", navInventory: "Products & Stock", navOrders: "Invoice Archive", navReports: "Reports",
    language: "Language", newInvoice: "＋ New Invoice", todaySales: "Today's Sales", completedInvoices: "Completed invoices",
    todayOrders: "Today's Orders", salesInvoices: "Sales invoices", lowStockItems: "Low-stock Items", belowTen: "Below 10 units",
    stockValue: "Stock Value", atCurrentPrice: "At current sales price", recentInvoices: "Recent Invoices", viewAll: "View all",
    restockAlerts: "Restock Alerts", selectProducts: "Select Products", search: "Search", searchProduct: "Name, SKU or category",
    currentSale: "Current Sale", clear: "Clear", customerName: "Customer Name", walkInCompany: "Walk-in / Company name",
    subtotal: "Subtotal", total: "Total", confirmInvoice: "Confirm Invoice", confirmHelp: "Cloud stock will be deducted and the invoice archived.",
    productsStock: "Products & Live Stock", searchProducts: "Search products", invoiceArchive: "Invoice Archive",
    searchInvoice: "Invoice no. or customer", invoicePreview: "Invoice Preview", close: "Close", printInvoice: "Print Invoice",
    overviewTitle: "Overview", saleTitle: "New Invoice", inventoryTitle: "Products & Stock", ordersTitle: "Invoice Archive", reportsTitle: "Management Reports",
    localDemo: "Local demo mode", localDemoDetail: "Connects to Firestore after deployment", firebaseConnected: "Firebase connected",
    syncing: "Syncing live", connectionFailed: "Firebase connection failed", demoFallback: "Using demo mode",
    demoNotice: "Local demo data is active. GitHub Actions will connect the deployed site to Firebase automatically.",
    noInvoices: "No invoices yet.", items: "items", invoiceNo: "INVOICE NO.", customer: "CUSTOMER", date: "DATE", amount: "AMOUNT",
    print: "Print", stockHealthy: "Stock levels are healthy.", stock: "Stock", noProducts: "No matching products found.",
    emptyCart: "Select a product to add it to this invoice.", remove: "Remove", insufficient: "has insufficient stock.",
    invoiceCompleted: "has been completed and archived.", invoiceFailed: "Unable to create invoice", walkIn: "Walk-in Customer",
    product: "PRODUCT", category: "CATEGORY", salesPrice: "SALES PRICE", permittedRange: "PERMITTED RANGE", liveStock: "LIVE STOCK", status: "STATUS",
    outOfStock: "Out of stock", lowStock: "Low stock", available: "Available", billedTo: "BILLED TO", invoiceDate: "INVOICE DATE",
    quantity: "QTY", unitPrice: "UNIT PRICE",
    readProductsFailed: "Unable to read products", readOrdersFailed: "Unable to read invoices", readMovementsFailed: "Unable to read stock movements", firebaseSetupFailed: "Firebase setup is incomplete",
    activeDepartment: "Active department", salesDepartment: "Sales Department", officeDepartment: "Office and Field Department", managerRole: "Owner and Manager", prototypeAccess: "Prototype access view", officeArea: "Office area",
    minPrice: "Min", maxPrice: "Max", setPrice: "Set price", priceOutOfRange: "Price must stay within the permitted range.",
    stockMovement: "Stock In and Out", selectProduct: "Select Product", movementType: "Movement Type", stockIn: "Stock In", stockOut: "Stock Out",
    referenceNote: "Reference Note", referencePlaceholder: "Supplier delivery or stock issue", recordMovement: "Record Movement",
    movementHelp: "Updates live stock and stores an audit record.", recentMovements: "Recent Movements", noMovements: "No stock movements yet.",
    movementSaved: "Stock movement recorded.", movementFailed: "Unable to record movement", supplierDelivery: "Supplier delivery", stockIssue: "Stock issue",
    reportSales: "Recorded Sales", allInvoices: "All archived invoices", reportInvoices: "Total Invoices", digitalRecords: "Digital records",
    unitsSold: "Units Sold", deductedFromStock: "Automatically deducted", inventoryUnits: "Inventory Units", currentStock: "Current live stock",
    topProducts: "Top Selling Products", inventorySummary: "Inventory Summary", printReport: "Print Report", noSalesData: "No sales data yet.",
    units: "units", reportTitle: "Sales and Inventory Report", generatedOn: "Generated on", officeCopy: "OFFICE COPY", customerCopy: "CUSTOMER COPY", thankYou: "Thank you for your business. Wura Electrical Appliances Retail Store."
  },
  ms: {
    brandSubtitle: "Jualan dan Inventori", navOverview: "Gambaran Keseluruhan", navSale: "Invois Baharu", navInventory: "Produk & Stok", navOrders: "Arkib Invois", navReports: "Laporan",
    language: "Bahasa", newInvoice: "＋ Invois Baharu", todaySales: "Jualan Hari Ini", completedInvoices: "Invois selesai",
    todayOrders: "Pesanan Hari Ini", salesInvoices: "Invois jualan", lowStockItems: "Item Stok Rendah", belowTen: "Kurang daripada 10 unit",
    stockValue: "Nilai Stok", atCurrentPrice: "Berdasarkan harga semasa", recentInvoices: "Invois Terkini", viewAll: "Lihat semua",
    restockAlerts: "Peringatan Stok", selectProducts: "Pilih Produk", search: "Cari", searchProduct: "Nama, SKU atau kategori",
    currentSale: "Jualan Semasa", clear: "Kosongkan", customerName: "Nama Pelanggan", walkInCompany: "Pelanggan terus / Nama syarikat",
    subtotal: "Subjumlah", total: "Jumlah", confirmInvoice: "Sahkan Invois", confirmHelp: "Stok awan akan ditolak dan invois akan diarkibkan.",
    productsStock: "Produk & Stok Langsung", searchProducts: "Cari produk", invoiceArchive: "Arkib Invois",
    searchInvoice: "No. invois atau pelanggan", invoicePreview: "Pratonton Invois", close: "Tutup", printInvoice: "Cetak Invois",
    overviewTitle: "Gambaran Keseluruhan", saleTitle: "Invois Baharu", inventoryTitle: "Produk & Stok", ordersTitle: "Arkib Invois", reportsTitle: "Laporan Pengurusan",
    localDemo: "Mod demo tempatan", localDemoDetail: "Bersambung ke Firestore selepas diterbitkan", firebaseConnected: "Firebase disambungkan",
    syncing: "Menyegerak secara langsung", connectionFailed: "Sambungan Firebase gagal", demoFallback: "Menggunakan mod demo",
    demoNotice: "Data demo tempatan sedang digunakan. GitHub Actions akan menyambungkan laman yang diterbitkan ke Firebase secara automatik.",
    noInvoices: "Belum ada invois.", items: "item", invoiceNo: "NO. INVOIS", customer: "PELANGGAN", date: "TARIKH", amount: "JUMLAH",
    print: "Cetak", stockHealthy: "Tahap stok adalah mencukupi.", stock: "Stok", noProducts: "Tiada produk yang sepadan.",
    emptyCart: "Pilih produk untuk ditambah ke invois ini.", remove: "Buang", insufficient: "tidak mempunyai stok yang mencukupi.",
    invoiceCompleted: "telah selesai dan diarkibkan.", invoiceFailed: "Invois tidak dapat dibuat", walkIn: "Pelanggan Terus",
    product: "PRODUK", category: "KATEGORI", salesPrice: "HARGA JUALAN", permittedRange: "JULAT DIBENARKAN", liveStock: "STOK LANGSUNG", status: "STATUS",
    outOfStock: "Kehabisan stok", lowStock: "Stok rendah", available: "Tersedia", billedTo: "DIBILKAN KEPADA", invoiceDate: "TARIKH INVOIS",
    quantity: "KUANTITI", unitPrice: "HARGA UNIT",
    readProductsFailed: "Produk tidak dapat dibaca", readOrdersFailed: "Invois tidak dapat dibaca", readMovementsFailed: "Pergerakan stok tidak dapat dibaca", firebaseSetupFailed: "Tetapan Firebase belum lengkap",
    activeDepartment: "Jabatan aktif", salesDepartment: "Jabatan Jualan", officeDepartment: "Jabatan Pejabat dan Lapangan", managerRole: "Pemilik dan Pengurus", prototypeAccess: "Paparan akses prototaip", officeArea: "Ruang pejabat",
    minPrice: "Min", maxPrice: "Maks", setPrice: "Tetapkan harga", priceOutOfRange: "Harga mesti berada dalam julat yang dibenarkan.",
    stockMovement: "Stok Masuk dan Keluar", selectProduct: "Pilih Produk", movementType: "Jenis Pergerakan", stockIn: "Stok Masuk", stockOut: "Stok Keluar",
    referenceNote: "Nota Rujukan", referencePlaceholder: "Penghantaran pembekal atau pengeluaran stok", recordMovement: "Rekod Pergerakan",
    movementHelp: "Mengemas kini stok langsung dan menyimpan rekod audit.", recentMovements: "Pergerakan Terkini", noMovements: "Belum ada pergerakan stok.",
    movementSaved: "Pergerakan stok telah direkodkan.", movementFailed: "Pergerakan stok tidak dapat direkodkan", supplierDelivery: "Penghantaran pembekal", stockIssue: "Pengeluaran stok",
    reportSales: "Jualan Direkodkan", allInvoices: "Semua invois diarkibkan", reportInvoices: "Jumlah Invois", digitalRecords: "Rekod digital",
    unitsSold: "Unit Terjual", deductedFromStock: "Ditolak secara automatik", inventoryUnits: "Unit Inventori", currentStock: "Stok semasa",
    topProducts: "Produk Terlaris", inventorySummary: "Ringkasan Inventori", printReport: "Cetak Laporan", noSalesData: "Belum ada data jualan.",
    units: "unit", reportTitle: "Laporan Jualan dan Inventori", generatedOn: "Dijana pada", officeCopy: "SALINAN PEJABAT", customerCopy: "SALINAN PELANGGAN", thankYou: "Terima kasih atas pembelian anda. Kedai Runcit Peralatan Elektrik Wura."
  }
};

const savedLanguage = localStorage.getItem("orderflow-language");
const initialLanguage = savedLanguage === "ms" ? "ms" : "en";
const savedRole = localStorage.getItem("wura-role");
const initialRole = ["sales", "office", "manager"].includes(savedRole) ? savedRole : "sales";
const t = (key) => translations[state?.language || initialLanguage][key] || translations.en[key] || key;

const demoProducts = [
  { id: "P1001", sku: "EA-1001", name: "Electric Kettle 1.7L", nameMs: "Cerek Elektrik 1.7L", category: "Kitchen Appliances", categoryMs: "Peralatan Dapur", minPriceCents: 6900, priceCents: 7900, maxPriceCents: 9500, stock: 24 },
  { id: "P1002", sku: "EA-1002", name: "Digital Rice Cooker 1.8L", nameMs: "Periuk Nasi Digital 1.8L", category: "Kitchen Appliances", categoryMs: "Peralatan Dapur", minPriceCents: 14900, priceCents: 16900, maxPriceCents: 19900, stock: 15 },
  { id: "P1003", sku: "EA-1003", name: "Table Fan 12 Inch", nameMs: "Kipas Meja 12 Inci", category: "Cooling", categoryMs: "Penyejukan", minPriceCents: 10900, priceCents: 12900, maxPriceCents: 14900, stock: 8 },
  { id: "P1004", sku: "EA-1004", name: "Multi Purpose Blender", nameMs: "Pengisar Pelbagai Guna", category: "Kitchen Appliances", categoryMs: "Peralatan Dapur", minPriceCents: 12900, priceCents: 14500, maxPriceCents: 16900, stock: 12 },
  { id: "P1005", sku: "EA-1005", name: "Microwave Oven 20L", nameMs: "Ketuhar Gelombang Mikro 20L", category: "Kitchen Appliances", categoryMs: "Peralatan Dapur", minPriceCents: 39900, priceCents: 42900, maxPriceCents: 48900, stock: 5 },
  { id: "P1006", sku: "EA-1006", name: "Air Fryer 4.5L", nameMs: "Penggoreng Udara 4.5L", category: "Kitchen Appliances", categoryMs: "Peralatan Dapur", minPriceCents: 33900, priceCents: 36900, maxPriceCents: 42900, stock: 7 },
  { id: "P1007", sku: "EA-1007", name: "Induction Cooker", nameMs: "Dapur Induksi", category: "Kitchen Appliances", categoryMs: "Peralatan Dapur", minPriceCents: 19900, priceCents: 21900, maxPriceCents: 25900, stock: 10 },
  { id: "P1008", sku: "EA-1008", name: "Standing Fan 16 Inch", nameMs: "Kipas Berdiri 16 Inci", category: "Cooling", categoryMs: "Penyejukan", minPriceCents: 16900, priceCents: 18900, maxPriceCents: 22900, stock: 9 },
  { id: "P1009", sku: "EA-1009", name: "Bagless Vacuum Cleaner", nameMs: "Pembersih Vakum Tanpa Beg", category: "Home Appliances", categoryMs: "Peralatan Rumah", minPriceCents: 27900, priceCents: 29900, maxPriceCents: 35900, stock: 6 },
  { id: "P1010", sku: "EA-1010", name: "Instant Water Heater", nameMs: "Pemanas Air Segera", category: "Home Appliances", categoryMs: "Peralatan Rumah", minPriceCents: 42900, priceCents: 45900, maxPriceCents: 52900, stock: 4 },
  { id: "P1011", sku: "EA-1011", name: "43 Inch Smart LED TV", nameMs: "TV LED Pintar 43 Inci", category: "Entertainment", categoryMs: "Hiburan", minPriceCents: 109900, priceCents: 119900, maxPriceCents: 139900, stock: 3 },
  { id: "P1012", sku: "EA-1012", name: "Two Door Refrigerator 250L", nameMs: "Peti Sejuk Dua Pintu 250L", category: "Home Appliances", categoryMs: "Peralatan Rumah", minPriceCents: 164900, priceCents: 174900, maxPriceCents: 199900, stock: 2 }
];

const state = { products: [], orders: [], movements: [], cart: new Map(), mode: "demo", busy: false, language: initialLanguage, role: initialRole };
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const displayName = (product) => state.language === "ms" ? (product.nameMs || product.name) : product.name;
const displayCategory = (product) => state.language === "ms" ? (product.categoryMs || product.category) : product.category;

function applyLanguage() {
  document.documentElement.lang = state.language;
  $("#language-select").value = state.language;
  $$('[data-i18n]').forEach((element) => { element.textContent = t(element.dataset.i18n); });
  $$('[data-i18n-placeholder]').forEach((element) => { element.placeholder = t(element.dataset.i18nPlaceholder); });
  const activeView = $(".nav-item.active")?.dataset.view || "overview";
  navigate(activeView, false);
  $("#today-label").textContent = new Intl.DateTimeFormat(state.language === "ms" ? "ms-MY" : "en-MY", { dateStyle: "full" }).format(new Date());
  $("#cloud-label").textContent = state.mode === "cloud" ? t("firebaseConnected") : t("localDemo");
  $("#cloud-detail").textContent = state.mode === "cloud" ? t("syncing") : t("localDemoDetail");
  applyRoleAccess();
  renderAll();
}

function applyRoleAccess() {
  document.body.dataset.role = state.role;
  $("#role-select").value = state.role;
  const officeAccess = state.role === "office";
  $(".movement-panel").hidden = !officeAccess;
  $("#save-movement").disabled = !officeAccess || state.busy;
}

function demoLoad() {
  const storedProducts = JSON.parse(localStorage.getItem("wura-demo-products-v1") || "null");
  const storedOrders = JSON.parse(localStorage.getItem("orderflow-demo-orders") || "[]");
  const storedMovements = JSON.parse(localStorage.getItem("wura-demo-movements") || "[]");
  state.products = storedProducts || structuredClone(demoProducts);
  state.orders = storedOrders;
  state.movements = storedMovements;
  demoSave();
  renderAll();
}

function demoSave() {
  localStorage.setItem("wura-demo-products-v1", JSON.stringify(state.products));
  localStorage.setItem("orderflow-demo-orders", JSON.stringify(state.orders));
  localStorage.setItem("wura-demo-movements", JSON.stringify(state.movements));
}

function showNotice(message, error = false) {
  const notice = $("#notice");
  notice.textContent = message;
  notice.classList.remove("hidden", "error");
  if (error) notice.classList.add("error");
  window.clearTimeout(showNotice.timer);
  showNotice.timer = window.setTimeout(() => notice.classList.add("hidden"), 6500);
}

async function connectFirebase() {
  const configured = firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith("YOUR_") &&
    firebaseConfig.projectId && !firebaseConfig.projectId.startsWith("YOUR_");

  if (!configured) {
    state.mode = "demo";
    $("#cloud-label").textContent = t("localDemo");
    $("#cloud-detail").textContent = t("localDemoDetail");
    showNotice(t("demoNotice"));
    demoLoad();
    return;
  }

  try {
    const app = initializeApp(firebaseConfig);
    const auth = getAuth(app);
    const credential = await signInAnonymously(auth);
    state.uid = credential.user.uid;
    state.db = getFirestore(app);
    state.mode = "cloud";
    $("#cloud-label").textContent = t("firebaseConnected");
    $("#cloud-detail").textContent = t("syncing");

    const productSnapshot = await getDocs(collection(state.db, "products"));
    if (productSnapshot.empty) await seedProducts();

    onSnapshot(query(collection(state.db, "products"), orderBy("name")), (snapshot) => {
      state.products = snapshot.docs.map((item) => ({ id: item.id, ...item.data() }));
      renderAll();
    }, (error) => showNotice(`${t("readProductsFailed")}: ${error.message}`, true));

    onSnapshot(query(collection(state.db, "orders"), orderBy("createdAt", "desc"), limit(100)), (snapshot) => {
      state.orders = snapshot.docs.map((item) => {
        const value = item.data();
        return { id: item.id, ...value, createdAtISO: value.createdAt?.toDate?.().toISOString() || value.createdAtISO };
      });
      renderAll();
    }, (error) => showNotice(`${t("readOrdersFailed")}: ${error.message}`, true));

    onSnapshot(query(collection(state.db, "stockMovements"), orderBy("createdAt", "desc"), limit(50)), (snapshot) => {
      state.movements = snapshot.docs.map((item) => {
        const value = item.data();
        return { id: item.id, ...value, createdAtISO: value.createdAt?.toDate?.().toISOString() || value.createdAtISO };
      });
      renderMovements();
    }, (error) => showNotice(`${t("readMovementsFailed")}: ${error.message}`, true));
  } catch (error) {
    state.mode = "demo";
    $("#cloud-label").textContent = t("connectionFailed");
    $("#cloud-detail").textContent = t("demoFallback");
    showNotice(`${t("firebaseSetupFailed")}: ${error.message}`, true);
    demoLoad();
  }
}

async function seedProducts() {
  const batch = writeBatch(state.db);
  demoProducts.forEach((product) => {
    const { id, ...data } = product;
    batch.set(doc(state.db, "products", id), { ...data, updatedAt: serverTimestamp() });
  });
  await batch.commit();
}

function navigate(view, scroll = true) {
  const labels = {
    overview: ["SALES CONTROL", t("overviewTitle")],
    sale: ["NEW INVOICE", t("saleTitle")],
    inventory: ["INVENTORY CONTROL", t("inventoryTitle")],
    orders: ["DOCUMENT ARCHIVE", t("ordersTitle")],
    reports: ["MANAGEMENT INFORMATION", t("reportsTitle")]
  };
  $$(".view").forEach((item) => item.classList.toggle("active", item.id === `view-${view}`));
  $$(".nav-item").forEach((item) => item.classList.toggle("active", item.dataset.view === view));
  $("#page-eyebrow").textContent = labels[view][0];
  $("#page-title").textContent = labels[view][1];
  if (scroll) window.scrollTo({ top: 0, behavior: "smooth" });
}

function renderAll() {
  renderMetrics();
  renderRecentOrders();
  renderLowStock();
  renderProducts();
  renderCart();
  renderInventory();
  renderOrders();
  renderMovements();
  renderReports();
}

function renderMetrics() {
  const todayOrders = state.orders.filter((order) => (order.createdAtISO || "").slice(0, 10) === todayKey());
  const sales = todayOrders.reduce((sum, order) => sum + Number(order.totalCents || 0), 0);
  const low = state.products.filter((product) => product.stock < 10).length;
  const stockValue = state.products.reduce((sum, product) => sum + product.priceCents * product.stock, 0);
  $("#metric-sales").textContent = money.format(sales / 100);
  $("#metric-orders").textContent = todayOrders.length;
  $("#metric-low").textContent = low;
  $("#metric-stock-value").textContent = money.format(stockValue / 100);
}

function orderRows(orders, action = true) {
  if (!orders.length) return `<div class="empty-state">${t("noInvoices")}</div>`;
  return `<table><thead><tr><th>${t("invoiceNo")}</th><th>${t("customer")}</th><th>${t("date")}</th><th>${t("amount")}</th>${action ? "<th></th>" : ""}</tr></thead><tbody>${orders.map((order) => `
    <tr>
      <td><div class="cell-main">${escapeHtml(order.orderNo)}</div><div class="cell-sub">${order.items?.length || 0} ${t("items")}</div></td>
      <td>${escapeHtml(order.customerName || t("walkIn"))}</td>
      <td>${formatDate(order.createdAtISO)}</td>
      <td><strong>${money.format((order.totalCents || 0) / 100)}</strong></td>
      ${action ? `<td><button class="table-action" data-print-order="${order.id}">${t("print")}</button></td>` : ""}
    </tr>`).join("")}</tbody></table>`;
}

function renderRecentOrders() {
  $("#recent-orders").innerHTML = orderRows(state.orders.slice(0, 5));
}

function renderLowStock() {
  const low = state.products.filter((product) => product.stock < 10).sort((a, b) => a.stock - b.stock);
  $("#low-stock-list").innerHTML = low.length ? low.slice(0, 5).map((product) => `
    <div class="stock-item"><div><strong>${escapeHtml(displayName(product))}</strong><small>${escapeHtml(product.sku)} · ${escapeHtml(displayCategory(product))}</small></div><span class="stock-count">${product.stock}</span></div>
  `).join("") : `<div class="empty-state">${t("stockHealthy")}</div>`;
}

function productMatches(product, text) {
  const haystack = `${product.name} ${product.nameMs || ""} ${product.sku} ${product.category} ${product.categoryMs || ""}`.toLowerCase();
  return haystack.includes(text.trim().toLowerCase());
}

function renderProducts() {
  const text = $("#product-search").value;
  const products = state.products.filter((product) => productMatches(product, text));
  $("#product-grid").innerHTML = products.length ? products.map((product) => `
    <button class="product-card" data-add-product="${product.id}" ${product.stock <= 0 ? "disabled" : ""}>
      <span class="sku">${escapeHtml(product.sku)} · ${escapeHtml(displayCategory(product))}</span>
      <strong>${escapeHtml(displayName(product))}</strong>
      <span class="product-meta"><span class="product-price">${money.format(product.priceCents / 100)}</span><span class="product-stock">${t("stock")} ${product.stock}</span></span>
      <small class="price-range">${t("minPrice")} ${money.format(productMin(product) / 100)} · ${t("maxPrice")} ${money.format(productMax(product) / 100)}</small>
    </button>
  `).join("") : `<div class="empty-state">${t("noProducts")}</div>`;
}

function addToCart(id) {
  const product = state.products.find((item) => item.id === id);
  if (!product) return;
  const current = state.cart.get(id) || { quantity: 0, priceCents: product.priceCents };
  if (current.quantity >= product.stock) return showNotice(`${displayName(product)} ${t("insufficient")}`, true);
  state.cart.set(id, { ...current, quantity: current.quantity + 1 });
  renderCart();
}

function changeQuantity(id, delta) {
  const product = state.products.find((item) => item.id === id);
  if (!product) return;
  const current = state.cart.get(id) || { quantity: 0, priceCents: product.priceCents };
  const next = current.quantity + delta;
  if (next <= 0) state.cart.delete(id);
  else if (next > product.stock) showNotice(`${displayName(product)} ${t("insufficient")}`, true);
  else state.cart.set(id, { ...current, quantity: next });
  renderCart();
}

function changeLinePrice(id, value) {
  const product = state.products.find((item) => item.id === id);
  const current = state.cart.get(id);
  if (!product || !current) return;
  const priceCents = Math.round(Number(value) * 100);
  if (!Number.isFinite(priceCents) || priceCents < productMin(product) || priceCents > productMax(product)) {
    showNotice(t("priceOutOfRange"), true);
    renderCart();
    return;
  }
  state.cart.set(id, { ...current, priceCents });
  renderCart();
}

function productMin(product) {
  return Number(product.minPriceCents ?? Math.round(product.priceCents * 0.9));
}

function productMax(product) {
  return Number(product.maxPriceCents ?? Math.round(product.priceCents * 1.1));
}

function cartLines() {
  return [...state.cart.entries()].map(([id, cartItem]) => {
    const product = state.products.find((item) => item.id === id);
    return product ? { ...product, quantity: cartItem.quantity, salePriceCents: cartItem.priceCents, lineTotalCents: cartItem.priceCents * cartItem.quantity } : null;
  }).filter(Boolean);
}

function renderCart() {
  const lines = cartLines();
  $("#cart-items").innerHTML = lines.length ? lines.map((line) => `
    <div class="cart-row">
      <div class="cart-row-head"><strong>${escapeHtml(displayName(line))}</strong><span>${money.format(line.lineTotalCents / 100)}</span></div>
      <label class="price-control"><span>${t("setPrice")}</span><input data-line-price="${line.id}" type="number" min="${(productMin(line) / 100).toFixed(2)}" max="${(productMax(line) / 100).toFixed(2)}" step="0.01" value="${(line.salePriceCents / 100).toFixed(2)}"><small>${money.format(productMin(line) / 100)} – ${money.format(productMax(line) / 100)}</small></label>
      <div class="cart-controls">
        <div class="qty-stepper"><button data-qty="-1" data-product-id="${line.id}">−</button><strong>${line.quantity}</strong><button data-qty="1" data-product-id="${line.id}">＋</button></div>
        <button class="remove-btn" data-remove-product="${line.id}">${t("remove")}</button>
      </div>
    </div>
  `).join("") : `<div class="empty-state">${t("emptyCart")}</div>`;
  const total = lines.reduce((sum, line) => sum + line.lineTotalCents, 0);
  $("#cart-subtotal").textContent = money.format(total / 100);
  $("#cart-total").textContent = money.format(total / 100);
  $("#save-order").disabled = state.busy || !lines.length;
}

async function saveOrder() {
  const lines = cartLines();
  if (!lines.length || state.busy) return;
  state.busy = true;
  renderCart();
  const now = new Date();
  const orderNo = `SO-${now.toISOString().slice(2, 10).replaceAll("-", "")}-${String(now.getTime()).slice(-5)}`;
  const order = {
    orderNo,
    customerName: $("#customer-name").value.trim() || t("walkIn"),
    createdAtISO: now.toISOString(),
    totalCents: lines.reduce((sum, line) => sum + line.lineTotalCents, 0),
    status: "completed",
    items: lines.map((line) => ({ productId: line.id, sku: line.sku, name: line.name, nameMs: line.nameMs || line.name, quantity: line.quantity, priceCents: line.salePriceCents, lineTotalCents: line.lineTotalCents }))
  };

  try {
    if (state.mode === "cloud") await saveCloudOrder(order);
    else {
      for (const line of lines) {
        const product = state.products.find((item) => item.id === line.id);
        if (!product || product.stock < line.quantity) throw new Error(`${displayName(line)} ${t("insufficient")}`);
      }
      lines.forEach((line) => { state.products.find((item) => item.id === line.id).stock -= line.quantity; });
      order.id = `demo-${now.getTime()}`;
      state.orders.unshift(order);
      demoSave();
    }
    state.cart.clear();
    $("#customer-name").value = "";
    renderAll();
    showInvoice(order);
    showNotice(`${orderNo} ${t("invoiceCompleted")}`);
  } catch (error) {
    showNotice(`${t("invoiceFailed")}: ${error.message}`, true);
  } finally {
    state.busy = false;
    renderCart();
  }
}

async function saveCloudOrder(order) {
  const orderRef = doc(collection(state.db, "orders"));
  await runTransaction(state.db, async (transaction) => {
    const snapshots = [];
    for (const line of order.items) {
      const ref = doc(state.db, "products", line.productId);
      snapshots.push({ line, ref, snapshot: await transaction.get(ref) });
    }
    snapshots.forEach(({ line, snapshot }) => {
      if (!snapshot.exists() || snapshot.data().stock < line.quantity) throw new Error(`${line.name} ${t("insufficient")}`);
      const product = snapshot.data();
      const minimum = Number(product.minPriceCents ?? Math.round(product.priceCents * 0.9));
      const maximum = Number(product.maxPriceCents ?? Math.round(product.priceCents * 1.1));
      if (line.priceCents < minimum || line.priceCents > maximum) throw new Error(t("priceOutOfRange"));
    });
    snapshots.forEach(({ line, ref, snapshot }) => transaction.update(ref, { stock: snapshot.data().stock - line.quantity, updatedAt: serverTimestamp() }));
    transaction.set(orderRef, { ...order, createdAt: serverTimestamp(), createdBy: state.uid });
  });
  order.id = orderRef.id;
}

function renderInventory() {
  const text = $("#inventory-search").value;
  const products = state.products.filter((product) => productMatches(product, text));
  $("#inventory-table").innerHTML = products.length ? `<table><thead><tr><th>${t("product")}</th><th>${t("category")}</th><th>${t("salesPrice")}</th><th>${t("permittedRange")}</th><th>${t("liveStock")}</th><th>${t("status")}</th></tr></thead><tbody>${products.map((product) => `
    <tr><td><div class="cell-main">${escapeHtml(displayName(product))}</div><div class="cell-sub">${escapeHtml(product.sku)}</div></td><td>${escapeHtml(displayCategory(product))}</td><td>${money.format(product.priceCents / 100)}</td><td><span class="range-cell">${money.format(productMin(product) / 100)} – ${money.format(productMax(product) / 100)}</span></td><td><strong>${product.stock}</strong></td><td><span class="pill ${product.stock < 10 ? "low" : ""}">${product.stock <= 0 ? t("outOfStock") : product.stock < 10 ? t("lowStock") : t("available")}</span></td></tr>
  `).join("")}</tbody></table>` : `<div class="empty-state">${t("noProducts")}</div>`;

  const selected = $("#movement-product").value;
  $("#movement-product").innerHTML = state.products.map((product) => `<option value="${product.id}">${escapeHtml(product.sku)} · ${escapeHtml(displayName(product))} (${product.stock})</option>`).join("");
  if (state.products.some((product) => product.id === selected)) $("#movement-product").value = selected;
}

function renderOrders() {
  const text = $("#order-search").value.trim().toLowerCase();
  const orders = state.orders.filter((order) => `${order.orderNo} ${order.customerName}`.toLowerCase().includes(text));
  $("#orders-table").innerHTML = orderRows(orders);
}

function renderMovements() {
  const items = state.movements.slice(0, 8);
  $("#movement-list").innerHTML = items.length ? items.map((movement) => {
    const product = state.products.find((item) => item.id === movement.productId);
    const sign = movement.type === "in" ? "+" : "−";
    return `<div class="movement-item"><div><strong>${escapeHtml(product ? displayName(product) : movement.productName || movement.sku)}</strong><small>${escapeHtml(movement.note || (movement.type === "in" ? t("supplierDelivery") : t("stockIssue")))} · ${formatDate(movement.createdAtISO)}</small></div><span class="movement-qty ${movement.type}">${sign}${movement.quantity}</span></div>`;
  }).join("") : `<div class="empty-state">${t("noMovements")}</div>`;
}

async function saveMovement() {
  if (state.busy || state.role !== "office") return;
  const productId = $("#movement-product").value;
  const product = state.products.find((item) => item.id === productId);
  const type = $("#movement-type").value === "out" ? "out" : "in";
  const quantity = Number($("#movement-quantity").value);
  if (!product || !Number.isInteger(quantity) || quantity <= 0) return showNotice(t("movementFailed"), true);
  if (type === "out" && product.stock < quantity) return showNotice(`${displayName(product)} ${t("insufficient")}`, true);
  const movement = {
    productId,
    sku: product.sku,
    productName: product.name,
    type,
    quantity,
    note: $("#movement-note").value.trim() || (type === "in" ? t("supplierDelivery") : t("stockIssue")),
    createdAtISO: new Date().toISOString()
  };
  state.busy = true;
  $("#save-movement").disabled = true;
  try {
    if (state.mode === "cloud") await saveCloudMovement(product, movement);
    else {
      product.stock += type === "in" ? quantity : -quantity;
      movement.id = `movement-${Date.now()}`;
      state.movements.unshift(movement);
      demoSave();
    }
    $("#movement-quantity").value = "1";
    $("#movement-note").value = "";
    renderAll();
    showNotice(t("movementSaved"));
  } catch (error) {
    showNotice(`${t("movementFailed")}: ${error.message}`, true);
  } finally {
    state.busy = false;
    $("#save-movement").disabled = false;
  }
}

async function saveCloudMovement(product, movement) {
  const productRef = doc(state.db, "products", product.id);
  const movementRef = doc(collection(state.db, "stockMovements"));
  await runTransaction(state.db, async (transaction) => {
    const snapshot = await transaction.get(productRef);
    if (!snapshot.exists()) throw new Error(t("noProducts"));
    const currentStock = Number(snapshot.data().stock || 0);
    if (movement.type === "out" && currentStock < movement.quantity) throw new Error(`${product.name} ${t("insufficient")}`);
    const nextStock = currentStock + (movement.type === "in" ? movement.quantity : -movement.quantity);
    transaction.update(productRef, { stock: nextStock, updatedAt: serverTimestamp() });
    transaction.set(movementRef, { ...movement, createdAt: serverTimestamp(), createdBy: state.uid });
  });
}

function renderReports() {
  const totalSales = state.orders.reduce((sum, order) => sum + Number(order.totalCents || 0), 0);
  const unitsSold = state.orders.flatMap((order) => order.items || []).reduce((sum, item) => sum + Number(item.quantity || 0), 0);
  const inventoryUnits = state.products.reduce((sum, product) => sum + Number(product.stock || 0), 0);
  $("#report-sales").textContent = money.format(totalSales / 100);
  $("#report-invoices").textContent = state.orders.length;
  $("#report-units").textContent = unitsSold;
  $("#report-stock").textContent = inventoryUnits;

  const totals = new Map();
  state.orders.forEach((order) => (order.items || []).forEach((item) => {
    const current = totals.get(item.productId) || { name: item.name, nameMs: item.nameMs, sku: item.sku, quantity: 0, sales: 0 };
    current.quantity += Number(item.quantity || 0);
    current.sales += Number(item.lineTotalCents || 0);
    totals.set(item.productId, current);
  }));
  const top = [...totals.values()].sort((a, b) => b.quantity - a.quantity).slice(0, 6);
  $("#top-products").innerHTML = top.length ? top.map((item, index) => `<div class="report-row"><span class="rank">${index + 1}</span><div><strong>${escapeHtml(state.language === "ms" ? (item.nameMs || item.name) : item.name)}</strong><small>${escapeHtml(item.sku)} · ${item.quantity} ${t("units")}</small></div><b>${money.format(item.sales / 100)}</b></div>`).join("") : `<div class="empty-state">${t("noSalesData")}</div>`;

  const groups = new Map();
  state.products.forEach((product) => {
    const key = displayCategory(product);
    const value = groups.get(key) || { units: 0, value: 0 };
    value.units += Number(product.stock || 0);
    value.value += Number(product.stock || 0) * Number(product.priceCents || 0);
    groups.set(key, value);
  });
  $("#inventory-summary").innerHTML = [...groups.entries()].map(([category, value]) => `<div class="report-row"><div><strong>${escapeHtml(category)}</strong><small>${value.units} ${t("units")}</small></div><b>${money.format(value.value / 100)}</b></div>`).join("");
}

function printReport() {
  document.body.classList.add("printing-report");
  window.print();
  window.setTimeout(() => document.body.classList.remove("printing-report"), 250);
}

function showInvoice(order) {
  const rows = (order.items || []).map((item) => `<tr><td><div class="cell-main">${escapeHtml(state.language === "ms" ? (item.nameMs || item.name) : item.name)}</div><div class="cell-sub">${escapeHtml(item.sku)}</div></td><td>${item.quantity}</td><td>${money.format(item.priceCents / 100)}</td><td>${money.format(item.lineTotalCents / 100)}</td></tr>`).join("");
  const invoiceCopy = (copyLabel, duplicate = false) => `<section class="invoice-copy ${duplicate ? "duplicate-copy" : ""}">
      <div class="copy-label">${copyLabel}</div>
      <div class="invoice-brand"><div><h2>Wura Electrical Appliances</h2><p>Seremban Royal Hill · Sales Order & Invoicing System</p></div><div class="invoice-title"><strong>INVOICE</strong><span>${escapeHtml(order.orderNo)}</span></div></div>
      <div class="invoice-info"><div><small>${t("billedTo")}</small><h3>${escapeHtml(order.customerName || t("walkIn"))}</h3></div><div><small>${t("invoiceDate")}</small><h3>${formatDate(order.createdAtISO)}</h3></div></div>
      <table><thead><tr><th>${t("product")}</th><th>${t("quantity")}</th><th>${t("unitPrice")}</th><th>${t("amount")}</th></tr></thead><tbody>${rows}</tbody></table>
      <div class="invoice-total"><span>${t("total")}</span><strong>${money.format((order.totalCents || 0) / 100)}</strong></div>
      <p class="invoice-foot">${t("thankYou")}</p>
    </section>`;
  $("#invoice-content").innerHTML = invoiceCopy(t("customerCopy")) + invoiceCopy(t("officeCopy"), true);
  $("#invoice-dialog").showModal();
}

function formatDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : new Intl.DateTimeFormat(state.language === "ms" ? "ms-MY" : "en-MY", { dateStyle: "medium", timeStyle: "short" }).format(date);
}

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[character]));
}

document.addEventListener("click", (event) => {
  const nav = event.target.closest("[data-view], [data-go]");
  if (nav) navigate(nav.dataset.view || nav.dataset.go);
  const product = event.target.closest("[data-add-product]");
  if (product) addToCart(product.dataset.addProduct);
  const quantity = event.target.closest("[data-qty]");
  if (quantity) changeQuantity(quantity.dataset.productId, Number(quantity.dataset.qty));
  const remove = event.target.closest("[data-remove-product]");
  if (remove) { state.cart.delete(remove.dataset.removeProduct); renderCart(); }
  const print = event.target.closest("[data-print-order]");
  if (print) { const order = state.orders.find((item) => item.id === print.dataset.printOrder); if (order) showInvoice(order); }
});

document.addEventListener("focusout", (event) => {
  const price = event.target.closest("[data-line-price]");
  if (price) changeLinePrice(price.dataset.linePrice, price.value);
});

$("#product-search").addEventListener("input", renderProducts);
$("#inventory-search").addEventListener("input", renderInventory);
$("#order-search").addEventListener("input", renderOrders);
$("#clear-cart").addEventListener("click", () => { state.cart.clear(); renderCart(); });
$("#save-order").addEventListener("click", saveOrder);
$("#save-movement").addEventListener("click", saveMovement);
$("#print-report").addEventListener("click", printReport);
$("#close-invoice").addEventListener("click", () => $("#invoice-dialog").close());
$("#print-invoice").addEventListener("click", () => window.print());
$("#language-select").addEventListener("change", (event) => {
  state.language = event.target.value === "ms" ? "ms" : "en";
  localStorage.setItem("orderflow-language", state.language);
  applyLanguage();
});
$("#role-select").addEventListener("change", (event) => {
  state.role = ["sales", "office", "manager"].includes(event.target.value) ? event.target.value : "sales";
  localStorage.setItem("wura-role", state.role);
  applyRoleAccess();
});

applyLanguage();
connectFirebase();
