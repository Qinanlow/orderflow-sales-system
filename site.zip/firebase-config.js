// GitHub Actions 会在部署时以 FIREBASE_WEB_CONFIG secret 覆盖此档案。
// 保留占位值可在本机直接打开示范模式，不会写入云端资料。
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};
